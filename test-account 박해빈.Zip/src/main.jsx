import { createRoot } from 'react-dom/client'
import AcoountLayout from './pages/AcoountLayout'


createRoot(document.getElementById('root')).render(

    <AcoountLayout />

)
