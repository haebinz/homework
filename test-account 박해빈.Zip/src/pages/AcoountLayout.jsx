import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../assets/css/accountLayout.css';
import Type from '../components/Type';
import AccountList from '../components/AccountList';
import Buttons from '../components/Buttons';

function AcoountLayout(props) {

    const [getMoney,setGetMoney] = useState(0);
    const [spendMoney,setSpendMoney] = useState(0);
    const [totalMoney,setTotalMoney] = useState(0);
    const [accountList,setAccountList] = useState([]);
    const [inputUse,setInputUse]=useState('');
    const [moneyType,setMoneyType]=useState(null);
    const [inputMoney, setInputMoney] = useState('');
    
   

    const register = () =>{

       if (moneyType === null || moneyType === 'select') {
        alert('타입을 작성하십시오');
        return;
        }
        if(inputUse.trim().length===0 || inputMoney.trim().length===0){
            alert('내용을 작성하십시오');
            return;
        }
        const newItem = {
        id: Date.now(),
        type: moneyType, 
        contents : inputUse,
        amount: Number(inputMoney),
        completed: false
    };

    setAccountList((prev) => [...prev, newItem]);

   
    if (moneyType === 'get') {
        setGetMoney((prev) => prev + Number(inputMoney));
        setTotalMoney((prev) => prev + Number(inputMoney));
    } else {
        setSpendMoney((prev) => prev + Number(inputMoney));
        setTotalMoney((prev) => prev - Number(inputMoney));
    }

   
    setInputUse('');
    setInputMoney('');
    setMoneyType(null);
    }

    const deleted=(id)=>{

        const deletedItem = accountList.find(item => item.id === id);
        if (!deletedItem) return;

        const isConfirmed = window.confirm('정말 삭제하시겠습니까?');
        if (!isConfirmed) return;

        const updated = accountList.filter(item=>item.id !==id);
        setAccountList(updated);


        if (deletedItem.type === 'get') {
        setGetMoney(prev => prev - deletedItem.amount);
        setTotalMoney(prev => prev - deletedItem.amount);
            } else if (deletedItem.type === 'spend') {
        setSpendMoney(prev => prev - deletedItem.amount);
        setTotalMoney(prev => prev + deletedItem.amount);
            }

    }
    return (
        <div>
            <main className='container'>
                <section className='contents'>
                    <header className='text-center'>
                        <h2>가계부</h2>
                    </header>
                    <Type inputUse={inputUse} setInputUse={setInputUse} register={register} moneyType={moneyType} setMoneyType={setMoneyType} inputMoney={inputMoney} setInputMoney={setInputMoney} />
                    <section className='account text-end'>
                        <p>수입:{getMoney}원</p>
                        <p>지출:{spendMoney}원</p>
                        <p>총계:{totalMoney}원</p>
                    </section>
                    <AccountList accountList={accountList} deleted={deleted}/>

                </section>
            </main>
            
        </div>
    );
}

export default AcoountLayout;