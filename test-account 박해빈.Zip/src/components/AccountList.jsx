import React from 'react';
import {styled} from 'styled-components';
import '../assets/css/accountList.css';

const ListDiv = styled.div`
    display: flex;
    justify-content: space-between; 
    align-items: center;             
    width: 100%;
    background-color: white;
    border-radius: 10px;
    padding: 0.5rem 0.75rem;
    margin-top: 15px;
    height: 80px;
    overflow: hidden;   
    box-sizing: border-box;
    flex-shrink: 0;

`

function AccountList({accountList,deleted}) {
    return (
        <div className='account-list-box'>
            {accountList?.map((item) => (
                <ListDiv key={item.id}  >

                    <div style={{ flexGrow: 1, textAlign: 'left', paddingLeft: '1rem'}}>
                        <div>구분 : {item.type === 'get' ? '수입' : '지출'}</div>
                        <div>내용 : {item.contents}</div>
                        <div>금액 : {item.amount}원</div>
                    </div>
                    <div className='text-end d-flex gap-2' style={{ flexShrink: 0 }}>
                        <button type='button' className='btn btn-danger btn-sm'  onClick={()=>deleted(item.id)}>삭제</button>
                    </div>
                </ListDiv>
            ))}
        </div>
    );
}

export default AccountList;