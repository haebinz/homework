import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../assets/css/type.css';

function Type({inputUse,setInputUse,register,moneyType,setMoneyType,inputMoney,setInputMoney}) {
   

    return (
        <>
        <section className='inputs'>
        <section className='type'>
        <label htmlFor='money' className='money'>선택 :</label>
        <select value={moneyType || 'select'} onChange={(e) => setMoneyType(e.target.value)} className='sel'>
            <option value='select'>---- 선택 ----</option>
            <option value='get'>수입</option>
            <option value='spend'>지출</option>
        </select>
        </section>
        <section className='descript'>
            <label htmlFor='use' className='describe'>내용 :</label>
            <input type='text' id='use' placeholder='내용 입력' value={inputUse} onChange={(e)=>setInputUse(e.target.value)} ></input>
        </section>
        <section className='price'>
            <label htmlFor='howMuch' className='priceFor'>금액 :</label>
            <input type='number' id='howMuch' value={inputMoney} onChange={(e) => setInputMoney(e.target.value)}  ></input>
        </section>
        <button type='button' className='btn btn-primary' onClick={register} >등록</button>
        </section>
            
        </>
    );
}

export default Type;