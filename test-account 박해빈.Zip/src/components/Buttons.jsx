import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../assets/css/buttons.css';


function Buttons({isDisabled,allDeleted}) {
    return (
        <>
        <div className=' d-flex justify-content-end gap-2 mt-5'>
            <button type='button' className='btn btn-danger' disabled={isDisabled} onClick={allDeleted}>일괄 삭제</button>
        </div>
            
        </>
    );
}

export default Buttons;